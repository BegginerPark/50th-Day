class Main {
  public static void main(String[] args) {
  //   int result = factorial(4);
  //   System.out.println(result);
  // }
  // static int factorial(int n) {
  //   int result = 0;
  //   if (n==1) 
  //     result = 1;
  //   else
  //     result = n * factorial(n-1);
  //   return result;

  //6-16
  // int n = 21;
  // long result = 0;
  // for(int i = 1; i <= n; i++) {
  //   result = factorial(i);

  //   if (result == -1) {
  //     System.out.printf("유효하지 않은 값입니다. (0 < n <= 20): %d%n", n);
  //     break;
  //   }
  //   System.out.printf("%2d!=%20d%n", i, result);
  // }

  // }

  // static long factorial(int n) {
  //   if(n <= 0 || n> 20) return -1;
  //   if(n <= 1) return 1;
  //     return n * factorial(n-1);

    // 6-18
  //   int x = 2;
  //   int n = 5;
  //   long result = 0;

  //   for (int i = 1; i <= n; i++) {
  //     result += power(x, i);
  //   }
  //   System.out.println(result);
  // }

  // static long power(int x, int n) {
  //   if(n == 1) return x;
  //   return x * power(x,n-1);

    //6-19
    // System.out.println(MyMath2.add(200L, 100L));
    // System.out.println(MyMath2.subtract(200L, 100L));
    // System.out.println(MyMath2.multiply(200L, 100L));
    // System.out.println(MyMath2.divide(200.0, 100.0));

    // MyMath2 mm = new MyMath2 ();
    // mm.a = 200L;
    // mm.b = 100L;
    // System.out.println(mm.add());
    // System.out.println(mm.subtract());
    // System.out.println(mm.multiply());
    // System.out.println(mm.divide());

    //6-21
    // MyMath3 mm = new MyMath3();
    // System.out.println("mm.add(3,3) 결과:" + mm.add(3,3));
    // System.out.println("mm.add(3L,3) 결과:" + mm.add(3L,3));
    // System.out.println("mm.add(3,3L) 결과:" + mm.add(3,3L));
    // System.out.println("mm.add(3L,3L) 결과:" + mm.add(3L,3L));

    // int[] a = {100, 200, 300};
    // System.out.println("mm.add(a) 결과:" + mm.add(a));


    //6-22
  //   String[] strArr = {"100", "200", "300"};

  //   System.out.println(concatenate("", "100", "200", "300"));
  //   System.out.println(concatenate("-", strArr));
  //   System.out.println(concatenate(",", new String[] {"1","2","3"}));
  //   System.out.println("[" + concatenate(",", new String[0])+ "]");
  //   System.out.println("[" + concatenate(",")+ "]");

  // }

  // static String concatenate(String delim, String... args) {
  //   String result = "";
  //   for(String str : args) {
  //     result += str + delim;
  //   }
  //   return result;
  // }

  // static String concatenate(String... args) {
  //   return concatenate("", args);
  // }


    //6-25,26
    // Car c1 = new Car();
    // Car c2 = new Car("blue");
    // Car c3 = new Car("red", "manual", 2);
    // Car c2 = new Car(c1);

    // System.out.println("c1의 color =" + c1.color + ", gearType = " + c1.gearType + ", door = " + c1.door);
    // System.out.println("c2의 color =" + c2.color + ", gearType = " + c2.gearType + ", door = " + c2.door);
    // System.out.println("c3의 color =" + c3.color + ", gearType = " + c3.gearType + ", door = " + c3.door);
    // c1.door = 100;
    // System.out.println("c1.door=100; 수행후");
    // System.out.println("c1의 color =" + c1.color + ", gearType = " + c1.gearType + ", door = " + c1.door);
    // System.out.println("c2의 color =" + c2.color + ", gearType = " + c2.gearType + ", door = " + c2.door);
    

    //6-28
    for (int i = 0; i < arr.length; i++) 
      System.out.println("arr[" + i + "] : " + arr[i]);
  }
  static int[] arr = new int[10];
  static {
    for (int i = 0; i < arr.length; i++) {
      arr[i] = (int)(Math.random()*10) + 1;
    }
  }
}
// 6-19
//   class MyMath2 {
//     long a, b;

//     long add()      {return a + b;}
//     long subtract() {return a -b;}
//     long multiply() {return a * b;}
//     double divide() {return a / b;}

//     static long add(long a, long b)    {return a + b;}
//     static long subtract(long a, long b) {return a - b;}
//     static long multiply(long a, long b)  {return a * b;}
//     static double divide(double a, double b)  {return a / b ;}
// }

//6-21
// class MyMath3 {
//   int add(int a, int b) {
//     System.out.print("int add(int a, int b) - ");
//     return a+b;
//   }

//   long add(int a, long b) {
//     System.out.print("long add(int a, long b) - ");
//     return a+b;
//   }

//   long add(long a, int b) {
//     System.out.print("long add(long a, int b) - ");
//     return a+b;
//   }

//   long add(long a, long b) {
//     System.out.print("long add(long a, long b) - ");
//     return a+b;
//   }

//   int add(int[] a) {
//     System.out.print("int add(int[] a) - ");
//     int result = 0;
//     for(int i =0; i < a.length; i++) {
//       result += a[i];
//     }
//     return result;
//   }
// }


//6-25
// class Car {
//   String color;
//   String gearType;
//   int door;

//   Car() {
//     this("white","auto", 4);
//   }

//   // Car(String color) {
//   //   this(color, "auto" , 4);
//   // }

//   Car(Car c) { //인스턴스 복사를 위한 생성자.
//     color = c.color;
//     gearType = c.gearType;
//     door = c.door;
//   }

//   Car(String color, String gearType, int door) {
//     this.color = color;
//     this.gearType = gearType;
//     this.door = door;
//   }
// }
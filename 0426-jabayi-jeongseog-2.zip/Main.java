import static java.lang.System.out;
import static java.lang.Math.*;
class Main {
  public static void main(String[] args) {

    // 7-1
    // CaptionTv ctv = new CaptionTv();
    // ctv.channel = 10;
    // ctv.channelUp();
    // System.out.println(ctv.channel);
    // ctv.displayCaption("Hello, World");
    // ctv.caption = true; // 캡션 기능을 켠다.
    // ctv.displayCaption("Hello, World");


    // 7-5
    // Child c = new Child();
    // c.method();


    //7-11
    //System.out.println(Math.random());
    // out.println(random());

    //System.out.println("Math.PI : " + Math.PI);
    // out.println("Math.PI :" + PI);

    //7-13
    // Time t = new Time(12, 35, 20);
    // System.out.println(t);
    // // t.hour = 13;
    // t.setHour(t.getHour() + 1);
    // System.out.println(t);

    //7-21
    // Buyer b = new Buyer();
    // b.buy(new Tv());
    // b.buy(new Computer());

    // System.out.println("현재 남은 돈은 " + b.money + "만원입니다.");
    // System.out.println("현재 보너스점수는 " + b.bonusPoint + "점입니다.");


    //7-24
    Fighter f = new Fighter();

    if (f instanceof Unit)
      System.out.println("f는 Unit 클래스의 자손입니다.");
    if (f instanceof Fightable)
      System.out.println("f는 Fightable 인터페이스를 구현했습니다.");
    if (f instanceof Movable)
      System.out.println("f는 Movable 인터페이스를 구현했습니다.");
    if (f instanceof Attackable)
      System.out.println("f는 Attckable 인터페이스를 구현했습니다.");
    if (f instanceof Object)
      System.out.println("f는 Object 클래스의 자손입니다.");
  }
}

// 7-1
// class Tv {
//   boolean power; // 전우너 on/off
//   int channel; // 채널

//   void power()  { power = !power; }
//   void channelUp() { ++channel; }
//   void ChannelDown() { --channel; }
// }

// class CaptionTv extends Tv {
//   boolean caption; // 캡션상태(on/off)
//   void displayCaption(String text) {
//     if (caption) { // 캡션상태가 on(true)일 때만 text를 보여준다.
//       System.out.println(text);
//     }
//   }
// }

//7-5
// class Parent {
//   int x = 10;
// }

// class Child extends Parent {
//   void method() {
//     System.out.println("x = " + x);
//     System.out.println("this.x = " + this.x);
//     System.out.println("super.x = " + super.x);
//   }
// }


//7-13
// class Time{
//   private int hour, minute, second;

//   Time(int hour, int minute, int second) {
//     setHour(hour);
//     setMinute(minute);
//     setSecond(second);
//   }

//   public int getHour() {  return hour;}
//   public void setHour(int hour) {
//     if (hour < 0 || hour > 23) return;
//     this.hour = hour;
//   }

//   public int getMinute() {  return minute;}
//   public void setMinute(int minute) {
//     if (minute < 0 || minute > 59) return;
//     this.minute = minute;
//   }

//   public int getSecond() {  return second;}
//   public void setSecond(int second) {
//     if (second < 0 || second > 59) return;
//     this.second = second;
//   }

//   public String toString() {
//     return hour + ":" + minute + ":" + second;
//   }
// }


//7-21
// class Product {
//   int price;
//   int bonusPoint;

//   Product(int price) {
//     this.price = price;
//     bonusPoint = (int) (price/10.0);
//   }
// }

// class Tv extends Product {
//   Tv() {super(100);}
//   public String toString() { return "Tv";}
// }

// class Computer extends Product {
//   Computer() { super(200);}
//   public String toString() { return "Computer";}
// }

// class Buyer {
//   int money = 1000;
//   int bonusPoint = 0;

//   void buy(Product p) {
//     if (money < p.price) {
//       System.out.println("잔액이 부족하여 물건을 살 수 없습니다.");
//       return;
//     }
//     money -= p.price;
//     bonusPoint += p.bonusPoint;
//     System.out.println(p + "을/를 구입하셨습니다.");    
//   }
// }


//7-24
class Fighter extends Unit implements Fightable {
  public void move(int x, int y) { }
  public void attack(Unit u) {  }
}

class Unit {
  int currentHP;
  int x;
  int y;
}

interface Fightable extends Movable, Attackable { }
interface Movable { void move(int x, int y);}
interface Attackable { void attack(Unit u); }